import styled from "styled-components";

export const SelectorStyle = styled.div `
    margin: 20px 0;
    max-width: 100px;
    align-items: center;
    margin-left: 1390px;
  
`

