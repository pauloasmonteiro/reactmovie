import { useState } from "react";
import { SelectorStyle } from "./styles";

export function Selector(){

    const [newStatus, setNewStatus] = useState(2);

    return(
        <SelectorStyle>
            <select value={newStatus} onChange={(e)=> setNewStatus(e.target.value)}> 
                <option value="1">Now Playing</option>
                <option value="2">Popular</option>
                <option value="3">Top Rated</option>
            </select>            
        </SelectorStyle>        
    )

}