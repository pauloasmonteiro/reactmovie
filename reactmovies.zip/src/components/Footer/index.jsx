import { FooterStyle } from "./styles";

export function Footer(){
    return(
        <FooterStyle>
            <p>Projeto desenvolvido pela COTI Informática.</p>
        </FooterStyle>
    )
}