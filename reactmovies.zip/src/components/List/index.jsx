import axios from "axios";
import { useState } from "react";
import { useEffect } from "react";
import { CardsContent, CardsList, CartsItem } from "./styles";
import star from '../../images/star.svg'

export function List({menu, status}){
    
    const [items, setItems] = useState([]);

    var url = menu == 'movie' ? `https://api.themoviedb.org/3/movie` : `https://api.themoviedb.org/3/tv`
    if (status == '1'){
        url = `${url}/now_playing`
    } else if (status == '3'){
        url = `${url}/top_rated`
    } else {
        url = `${url}/popular`
    }    

    //USE EFFECT    
    useEffect(()=>{
        //console.log('Componente List renderizado');
        //get -> consultar
        //post -> enviar
        //put -> atualizar
        //delete -> excluir

        axios.get(url, {
            params : {
                page : 1,
                language: 'pt-BR',
                api_key: 'b5a21fdcdfd94bbea1dba5f7df3f9727'
            }
        })

        //sucesso
        .then(response => {
            setItems(response.data.results);
        })

        //erro
        .catch(exception=>{
            alert(exception.message);
        });

    }, [])

    return(
        <div className="container">
            <CardsList>
                {
                    items.map((item)=>(
                        <CartsItem key={item.id}>
                            <img src={`https://image.tmdb.org/t/p/original${item.backdrop_path}`} width={360} />
                            <CardsContent>
                                <h2>{menu == 'movie' ? item.title : item.name}</h2>
                                <h3>{menu == 'movie' ? item.release_date : item.release_date}</h3>
                                <span><img src={star} /> {menu == 'movie' ? item.vote_average : item.vote_average}</span>
                            </CardsContent>
                        </CartsItem>
                    ))
                }
            </CardsList>       
        </div>
    )

}